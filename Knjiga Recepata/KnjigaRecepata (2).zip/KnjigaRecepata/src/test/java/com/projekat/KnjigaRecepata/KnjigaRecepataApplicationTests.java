package com.projekat.KnjigaRecepata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnjigaRecepataApplicationTests {

	@Test
	void contextLoads() {
	}

}
