package com.projekat.KnjigaRecepata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnjigaRecepataApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnjigaRecepataApplication.class, args);
	}

}
